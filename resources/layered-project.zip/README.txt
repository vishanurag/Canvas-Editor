Sample Layered Project
Contains:
- background.png
- circle.png

Try blending these two images together in your project!
